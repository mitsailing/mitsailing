declare const _default: RGBColorSpace;
export default _default;
import RGBColorSpace from "../RGBColorSpace.js";
//# sourceMappingURL=rec2100-pq.d.ts.map